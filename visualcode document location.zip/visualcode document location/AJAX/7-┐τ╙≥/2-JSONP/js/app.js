const data = {
    name:"尚硅谷"
}



handle(data)