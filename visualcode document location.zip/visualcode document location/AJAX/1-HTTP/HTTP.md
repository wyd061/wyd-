#HTTP
HTTP(hypertext transport protocol) 协议【超文本传输协议】，协议详细规定了浏览器和万维网服务器之间相互通信的规则
约定，规则

##请求报文
重点是格式与参数
、、、

行                      (请求类型)POST    (url路径)/s?ie=utf-8 HTTP/1.1
头(格式为名字:空格+值)    Host：atguigu.com
                        Cookie：name=guigu
                        (请求体类型)Content-type：application/x-www-form-urlencoded
                        User-Agent：chrome 83
空行(必须得有)
体(GET请求请求体为空、POST请求请求体可以为空可以不为空)      usernam=admin&password=admin
、、、

##响应报文
、、、
行      HTTP/1.1(HTTP协议版本)   200(响应状态码)     OK(响应状态字符串)  
头      Content-Type：text/html;charset=utf-8
        Content-length：2048
        Content-encoding：gzip(压缩方式)
空行
体      <html>
            <head>
            </head>
            <body>
                <h1>尚硅谷</h1>
            </body>
        </html>
、、、
404 找不到
403 被禁止
401 未授权
500 内部错误
200 被允许


在js外部文件夹集成终端打开执行node .\文件夹名字启动服务器