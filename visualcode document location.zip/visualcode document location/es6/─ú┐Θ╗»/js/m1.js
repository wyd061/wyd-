//分别暴露
export let school = '尚硅谷'

export function teach(){
    console.log("我可以教你")
}