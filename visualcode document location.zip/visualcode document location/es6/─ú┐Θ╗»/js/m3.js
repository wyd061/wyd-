// 默认暴露
export default{
    school:"ATGUIGU",
    change:function(){
        console.log("我们跨域改变事件")
    }
}