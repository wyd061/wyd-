(function () {
    // 私有的数据
    var msg = 'my atguigu'
    // 操作数据的函数
    function doSomething() {
        console.log('doSomething()' + msg.toUpperCase())
    }
    function doOtherthing() {
        console.log('doOtherthing()' + msg.toLowerCase())
    }
    // 向外暴露对象(给外部使用的方法)

    // 这里相当于是将doSomething，doOtherthing这俩方法添加为对象，然后将这个对象作为一个window下的一个属性
    // 我们把这个属性命名为myMoudle2
    // 然后在html文件引入js模块以后，直接用myMoudle2.doSomething/doOtherthing来使用它的方法
    window.myMoudle2 = {
        doSomething: doSomething,
        doOtherthing: doOtherthing
    }

})()