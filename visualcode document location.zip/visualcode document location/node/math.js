// 定义一个模块math，提供和和积的方法
module.exports.add = function(a,b){
    return a+b;
}

exports.mul = function(a,b){
    return a*b;
}