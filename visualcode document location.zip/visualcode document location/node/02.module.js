console.log("我是一个模块，我是02.module.js");

// 我们可以通过exports来向外部暴露变量和方法
// 只需要将需要暴露给外部的变量或方法设置为exports的属性即可
exports.x = "我是02.module.js中的x";
exports.y = "我是y";
exports.fn = function(){
    
}