module.exports.name = "孙悟空";
module.exports.age = 18;
module.exports.sayName = function(){
    console.log("我是悟空")
}

module.exports = {
    name:"猪八戒",
    age:28,
    sayName:function(){
        console.log("我是猪八戒")
    }
}