// 异步文件写入
// 异步函数不可能有返回值，因为有了返回值就跟同步一样了，必须等返回结果出来才能继续运行

// fs.open(path,flags[,mode],callback)
    // 用来打开一个文件
    // 异步调用的方法，结果都是通过回调函数的参数返回的
    // 回调函数的两个参数
        //err   错误对象    如果没有错误则为null
        //fd    文件的描述符
// fs.write(fd, string[, position[, encoding]], callback)

// fs.close(fd,callback)
// 用来关闭文件


// 引入fs模块
var fs = require("fs")

// 打开文件
fs.open("hello2.txt","w",function(err,fd){
    // 判断是否出错
    // 如果err是出错的，那么err就是有值的，那么！err就是无值的(false)
    // 如果err没有出错，那么err就是无值的(null),那么!err就是有值的(true)

    // 这是微任务，所有在主线任务之后才会执行
    if(!err){
        // 如果没有出错，则对文件进行写入操作
        fs.write(fd,"这是异步写入的内容",function(err){
            if(!err){
                console.log("写入成功")
            }
            // 回调函数是最后执行的微任务，一旦执行了说明主线任务都已经完成了
            fs.close(fd,function(err){
                if(!err){
                    console.log("文件保存关闭成功")
                }
            })
        })
    }else{
        console.log(err)
    }
})