// import * as m1 from "./hello.js"
// 获取元素
const btn = document.getElementById("btn")

btn.onclick = function(){
    // import函数的返回结果是一个promise对象
    // promise对象成功的值就是模块里面暴露出来的对象
    import("./hello.js").then(module=>{
        module.hello()
    })
}